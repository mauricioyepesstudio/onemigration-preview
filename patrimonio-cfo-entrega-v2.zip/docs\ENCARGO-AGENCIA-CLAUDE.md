# Encargo para la agencia de Claude

Actúa como director de marca, diseñador de producto, UX writer, ingeniero full-stack y revisor financiero. Ya existe una aplicación privada llamada **Patrimonio CFO** publicada en `https://patrimonio-cfo-mauricio.myepes01.chatgpt.site`. Trabaja sobre su repositorio existente: Next.js/Vinext, React, TypeScript, Tailwind, Cloudflare Worker + D1. No comiences otro proyecto ni sustituyas el modelo de datos sin migración.

Lee primero `docs/IDENTIDAD-Y-UX.md`, `app/finance-app.tsx`, `app/api/finance/route.ts`, `app/api/loans/route.ts`, `db/schema.ts` y `public/brand/`. Preserva la privacidad de los datos, el acceso por usuario y el balance `activos - deudas = patrimonio`.

## Objetivo

Crear un producto para personas y familias que responda en segundos: cuánto tengo, cuánto debo, cómo cambió mi patrimonio y qué movimiento verificado explica el cambio. La marca debe parecer una herramienta financiera rigurosa y accesible, sin jerga contable innecesaria ni promesas de riqueza.

## Trabajo solicitado

1. Audita la identidad existente y refínala como sistema: símbolo y logotipo vectorial, versiones clara/oscura/monocroma, zona de protección, tamaño mínimo, paleta, tipografía, componentes, reglas de iconografía, voz y ejemplos correctos/incorrectos. Documenta toda decisión y entrega SVG fuente y assets exportables.
2. Diseña y construye la experiencia responsive: incorporación guiada, captura de cierres, comparación temporal, explicación de patrimonio, flujo de caja, seis ratios con definición, préstamos, metas, estados vacíos, errores y accesibilidad. Cada pantalla debe permitir una tarea real, no solo mostrar una maqueta.
3. Crea sistema de contenido social editable para 1:1, 4:5 y 9:16, con al menos tres publicaciones terminadas y sus captions. Usa ejemplos marcados como ilustrativos y no anuncies conexión bancaria hasta que exista.
4. Extiende el motor de datos con cuentas, activos, pasivos y transacciones con fuentes y fecha; mantén el historial y la conciliación contable. Propón migraciones aditivas; conserva los datos actuales. Nunca atribuyas apreciación, aportes o ahorro a un saldo agregado si no hay transacciones que lo demuestren.
5. Verifica con escenarios: banco −$500 y deuda −$1,000 implica patrimonio +$500 si lo demás no cambia; un pago de préstamo separa interés (gasto) y capital (reducción de pasivo); nuevas deudas, depreciación, patrimonio negativo, cuota menor al interés y meses faltantes.

## Entrega

Presenta primero inventario y riesgos del repositorio. Después implementa las mejoras en el código, muestra pantallas funcionales para móvil y desktop, ejecuta typecheck/build y pruebas de los cálculos que tengan riesgo real. Entrega archivos editables, enlaces de las piezas, cambios de código, migraciones, evidencia de verificación y asuntos pendientes. Mantén el acceso privado actual y publica los cambios verificados según el flujo de trabajo existente; no amplíes los permisos de lectura.

Prioridad: precisión del balance y privacidad, claridad UX, identidad visual, integración de datos, automatización. Pregunta solo si hay una decisión de marca o integración que no pueda resolverse a partir del repositorio y este encargo.
