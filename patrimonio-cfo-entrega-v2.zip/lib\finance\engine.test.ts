import { test } from "node:test";
import assert from "node:assert/strict";
import {
  type Account,
  type MonthClose,
  type Transaction,
  aggregateBalances,
  explainChange,
  explainWithLedger,
  goalProgress,
  missingMonths,
  monthFlow,
  netWorth,
  projectPayoff,
  ratios,
  splitPayment,
} from "./engine.ts";

const $ = (d: number) => Math.round(d * 100);
const close = (month: string, p: Partial<MonthClose> = {}): MonthClose => ({
  month, cash: 0, investments: 0, otherAssets: 0, debt: 0,
  income: null, living: null, interest: null, principal: null, contributions: null, housing: null, goal: null, ...p,
});

test("banco −$500 y deuda −$1,000 ⇒ patrimonio +$500", () => {
  const a = close("2026-07", { cash: $(3000), investments: $(10000), debt: $(8000) });
  const b = close("2026-08", { cash: $(2500), investments: $(10000), debt: $(7000) });
  const x = explainChange(a, b);
  assert.equal(x.cash, $(-500));
  assert.equal(x.debt, $(-1000));
  assert.equal(x.netWorth, $(500));
  assert.equal(x.reconciliationError, 0);
});

test("pago de préstamo separa interés (gasto) y capital (reducción de pasivo)", () => {
  // $10,000 al 12 % APR ⇒ interés mensual $100; cuota $300 ⇒ capital $200.
  const s = splitPayment($(10000), 1200, $(300));
  assert.deepEqual(s, { interest: $(100), principal: $(200), nonAmortizing: false, shortfall: 0 });

  const accounts: Account[] = [{ id: "bank", name: "Banco", kind: "cash" }, { id: "car", name: "Auto", kind: "liability" }];
  const txs: Transaction[] = [
    { id: "t1", date: "2026-08-05", kind: "interest", amount: s.interest, accountId: "bank", source: "manual" },
    { id: "t2", date: "2026-08-05", kind: "principal_payment", amount: s.principal, accountId: "bank", counterAccountId: "car", source: "manual" },
  ];
  const r = explainWithLedger(accounts, { bank: $(1000), car: $(10000) }, { bank: $(700), car: $(9800) }, txs);
  assert.equal(r.netWorthChange, $(-100)); // solo el interés reduce patrimonio
  assert.equal(r.byKind.interest, $(-100));
  assert.equal(r.byKind.principal_payment, 0); // capital: neutro
  assert.equal(r.unexplained, 0);
  assert.deepEqual(r.accountsUnreconciled, []);
});

test("coincide con el ejemplo publicado: cuota $302.58 = interés $84.74 + capital $217.84", () => {
  // Saldo que produce $84.74 de interés al 6.50 % APR.
  const s = splitPayment($(15644.31), 650, $(302.58));
  assert.equal(s.interest, $(84.74));
  assert.equal(s.principal, $(217.84));
});

test("nueva deuda: pedir prestado no cambia el patrimonio", () => {
  const a = close("2026-07", { cash: $(1000), debt: $(0) });
  const b = close("2026-08", { cash: $(6000), otherAssets: $(0), debt: $(5000) });
  const x = explainChange(a, b);
  assert.equal(x.netWorth, 0);
  assert.ok(x.notices.some((n) => n.code === "debt_increased" && n.amount === $(5000)));

  const accounts: Account[] = [{ id: "bank", name: "Banco", kind: "cash" }, { id: "loan", name: "Préstamo", kind: "liability" }];
  const r = explainWithLedger(accounts, { bank: $(1000), loan: 0 }, { bank: $(6000), loan: $(5000) }, [
    { id: "b1", date: "2026-08-02", kind: "borrowing", amount: $(5000), accountId: "bank", counterAccountId: "loan", source: "statement" },
  ]);
  assert.equal(r.netWorthChange, 0);
  assert.equal(r.unexplained, 0);
});

test("depreciación: solo se atribuye si hay transacción de valoración", () => {
  const accounts: Account[] = [{ id: "car", name: "Auto", kind: "other_asset" }];
  const withTx = explainWithLedger(accounts, { car: $(20000) }, { car: $(18000) }, [
    { id: "v1", date: "2026-08-31", kind: "valuation", amount: $(-2000), accountId: "car", source: "manual", description: "Tasación KBB" },
  ]);
  assert.equal(withTx.byKind.valuation, $(-2000));
  assert.equal(withTx.unexplained, 0);

  const noTx = explainWithLedger(accounts, { car: $(20000) }, { car: $(18000) }, []);
  assert.equal(noTx.byKind.valuation, 0); // nunca se inventa depreciación
  assert.equal(noTx.unexplained, $(-2000));
  assert.equal(noTx.accountsUnreconciled.length, 1);
});

test("inversiones: el cambio agregado nunca se etiqueta como apreciación", () => {
  const accounts: Account[] = [{ id: "bank", name: "Banco", kind: "cash" }, { id: "brk", name: "Broker", kind: "investment" }];
  // +$800 en broker: $500 aporte verificado; $300 sin explicar (mercado, dividendos o ambos).
  const r = explainWithLedger(accounts, { bank: $(2000), brk: $(10000) }, { bank: $(1500), brk: $(10800) }, [
    { id: "c1", date: "2026-08-10", kind: "contribution", amount: $(500), accountId: "bank", counterAccountId: "brk", source: "csv" },
  ]);
  assert.equal(r.byKind.contribution, 0);
  assert.equal(r.byKind.valuation, 0);
  assert.equal(r.unexplained, $(300));
  const x = explainChange(close("2026-07", { investments: $(10000) }), close("2026-08", { investments: $(10800) }));
  assert.ok(x.notices.some((n) => n.code === "investments_mixed"));
});

test("gasto cargado a tarjeta sube la deuda y baja el patrimonio", () => {
  const accounts: Account[] = [{ id: "cc", name: "Tarjeta", kind: "liability" }];
  const r = explainWithLedger(accounts, { cc: $(500) }, { cc: $(620) }, [
    { id: "e1", date: "2026-08-12", kind: "expense", amount: $(120), accountId: "cc", source: "statement" },
  ]);
  assert.equal(r.netWorthChange, $(-120));
  assert.equal(r.byKind.expense, $(-120));
  assert.equal(r.unexplained, 0);
});

test("patrimonio negativo: crecimiento % no interpretable, meta en 0 %", () => {
  const a = close("2026-07", { cash: $(1000), debt: $(5000), goal: $(10000) });
  const b = close("2026-08", { cash: $(1500), debt: $(4800), goal: $(10000) });
  assert.equal(netWorth(b), $(-3300));
  const g = ratios(b, a).find((r) => r.id === "netWorthGrowth")!;
  assert.equal(g.value, null);
  assert.match(g.missing!, /negativo/);
  assert.equal(goalProgress(b), 0);
  assert.ok(explainChange(a, b).notices.some((n) => n.code === "negative_net_worth"));
  // Cruce de negativo a positivo tampoco produce un % engañoso.
  const c = close("2026-09", { cash: $(6000), debt: $(4600) });
  assert.equal(ratios(c, b).find((r) => r.id === "netWorthGrowth")!.value, null);
});

test("cuota menor al interés: no amortiza y no hay fecha de liquidación", () => {
  const s = splitPayment($(20000), 2400, $(350)); // interés $400
  assert.equal(s.nonAmortizing, true);
  assert.equal(s.principal, 0);
  assert.equal(s.shortfall, $(50));
  assert.deepEqual(projectPayoff({ balance: $(20000), aprBps: 2400, payment: $(350) }), { months: null, totalInterest: null });
  // Cuota exactamente igual al interés tampoco amortiza.
  assert.equal(splitPayment($(20000), 2400, $(400)).nonAmortizing, true);
});

test("proyección de liquidación y última cuota parcial", () => {
  const p = projectPayoff({ balance: $(1000), aprBps: 0, payment: $(300) });
  assert.deepEqual(p, { months: 4, totalInterest: 0 });
  const q = projectPayoff({ balance: $(10000), aprBps: 1200, payment: $(300) });
  assert.equal(q.months, 41);
  assert.ok(q.totalInterest! > 0);
});

test("meses faltantes: se detectan y el crecimiento % se suspende", () => {
  assert.deepEqual(missingMonths(["2026-01", "2026-03", "2026-06"]), ["2026-02", "2026-04", "2026-05"]);
  assert.deepEqual(missingMonths(["2025-12", "2026-01"]), []);
  const a = close("2026-01", { cash: $(1000) });
  const b = close("2026-03", { cash: $(1400) });
  const x = explainChange(a, b);
  assert.equal(x.spanMonths, 2);
  assert.ok(x.notices.some((n) => n.code === "gap" && n.months === 1));
  assert.equal(ratios(b, a).find((r) => r.id === "netWorthGrowth")!.value, null);
});

test("capital declarado que no cuadra con la baja de deuda genera aviso", () => {
  const a = close("2026-07", { cash: $(3000), debt: $(8000) });
  const b = close("2026-08", { cash: $(2500), debt: $(7900), principal: $(500) });
  assert.ok(explainChange(a, b).notices.some((n) => n.code === "principal_exceeds_debt_drop"));
});

test("flujo: campos vacíos nunca se tratan como cero", () => {
  assert.deepEqual(monthFlow(close("2026-08", { income: $(5000), living: $(3000) })), { freeCashFlow: null, unallocated: null });
  const f = monthFlow(close("2026-08", { income: $(5000), living: $(3000), interest: $(100), principal: $(400), contributions: $(500) }));
  assert.deepEqual(f, { freeCashFlow: $(1900), unallocated: $(1000) });
});

test("seis ratios con definición; divisiones imposibles devuelven null", () => {
  const m = close("2026-08", { cash: $(6000), investments: $(20000), debt: $(13000), income: $(5000), living: $(2800), interest: $(200), principal: $(300), housing: $(1500) });
  const r = Object.fromEntries(ratios(m, close("2026-07", { cash: $(5000), investments: $(20000), debt: $(13300) })).map((x) => [x.id, x]));
  assert.equal(Object.keys(r).length, 6);
  for (const x of Object.values(r)) assert.ok(x.definition.length > 20);
  assert.equal(r.liquidity.value, 2);
  assert.equal(r.debtToAssets.value, 50);
  assert.equal(r.debtService.value, 10);
  assert.equal(r.freeCashFlowRate.value, 40);
  assert.equal(r.housing.value, 30);
  assert.equal(r.netWorthGrowth.value!.toFixed(2), (1300 / 11700 * 100).toFixed(2));

  const z = ratios(close("2026-08", { income: 0, living: 0, interest: 0, principal: 0, housing: 0 }));
  for (const x of z) assert.equal(x.value, null);
});

test("saldos por cuenta concilian con el cierre agregado", () => {
  const accounts: Account[] = [
    { id: "b1", name: "Cheques", kind: "cash" }, { id: "b2", name: "Ahorro", kind: "cash" },
    { id: "i1", name: "401k", kind: "investment" }, { id: "l1", name: "Auto", kind: "liability" },
  ];
  const agg = aggregateBalances(accounts, { b1: $(1200), b2: $(3000), i1: $(15000), l1: $(9000) });
  assert.deepEqual(agg, { cash: $(4200), investments: $(15000), otherAssets: 0, debt: $(9000) });
});
