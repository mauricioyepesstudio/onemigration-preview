# Captions · piezas sociales

Generado desde `brand/content/posts.json`. Todas las cifras son ilustrativas y se verifican con `lib/finance/engine.ts`. No anuncian acceso público ni conexión bancaria.

## 01-banco-baja

**Titular:** Tu banco bajó $500. ¿Tu patrimonio también?

El saldo del banco no cuenta toda la historia. Si este mes salieron $500 del banco pero tu deuda bajó $1,000, tu patrimonio subió $500. Activos menos deudas: siempre las dos columnas. Ejemplo ilustrativo.

#finanzaspersonales #patrimonio #educacionfinanciera

**Alt text:** Tu banco bajó $500. ¿Tu patrimonio también? Banco −$500 (salió dinero), Deuda −$1,000 (debes menos); Patrimonio +$500. Ejemplo ilustrativo.

## 02-dos-destinos

**Titular:** Cada cuota tiene dos destinos.

Una cuota de $302.58 no es un gasto de $302.58. En este ejemplo, $84.74 son interés (gasto) y $217.84 son capital: salen del banco y reducen tu deuda en la misma cantidad. La tasa y el saldo determinan el cálculo real. Ejemplo ilustrativo.

#prestamos #finanzaspersonales #deudas

**Alt text:** Cada cuota tiene dos destinos. Interés $84.74 (es gasto), Capital $217.84 (reduce la deuda); Cuota $302.58. Ejemplo ilustrativo.

## 03-nueva-deuda

**Titular:** Pedir prestado no te hace más rico.

Recibir un préstamo de $5,000 sube tu banco y tu deuda en lo mismo: el patrimonio no cambia. Lo que decide si mejora o empeora es qué haces con ese dinero y cuánto interés pagas. Ejemplo ilustrativo.

#deuda #finanzaspersonales #patrimonio

**Alt text:** Pedir prestado no te hace más rico. Banco +$5,000 (entra el préstamo), Deuda +$5,000 (debes más); Patrimonio $0. Ejemplo ilustrativo.
