# Patrimonio CFO — identidad de marca y producto

Versión 2 · 28 septiembre 2026. Añade el sistema de marca (§ Sistema de marca v2), la especificación UX por pantalla y el sistema social. La v1 se conserva debajo y en `brand/legacy-v1/`.

## Sistema de marca v2

### Auditoría de la v1 y decisiones

| Hallazgo en v1 | Decisión v2 | Motivo |
| --- | --- | --- |
| El logotipo usaba `<text>` en Arial | Texto convertido a trazos (`scripts/build-brand.mjs`) | Se ve igual en cualquier equipo, imprenta o herramienta |
| Lienzo de 660 px con ~250 px vacíos a la derecha | Lienzo ajustado al contenido | Se alinea y escala sin márgenes fantasma |
| "Mono" era bicolor (azul + blanco) | Mono real: una sola tinta con la P y la trayectoria caladas (transparentes) | Sirve para grabado, sello o una tinta sobre cualquier fondo |
| En oscuro, trazo `#127C70` sobre `#72E3B2` (3.22:1) | Trazo `#0B5147` (5.85:1) | Legible a 32 px |
| Los posts usaban una "P" tipográfica en un cuadro | Los posts usan el logotipo oscuro real | Una sola forma de marca |
| Cada formato de post se diseñaba a mano | Una fuente (`posts.json`) genera los tres formatos | Cambiar el texto no rompe el diseño; las cifras se verifican |

### Archivos

| Archivo | Uso |
| --- | --- |
| `logo-horizontal.svg` / `@2x.png` | Principal, sobre fondos claros |
| `logo-horizontal-dark.svg` / `@2x.png` | Sobre `#102A43` o fotografía oscura |
| `logo-horizontal-mono.svg` | Una tinta azul (documentos, sello) |
| `logo-horizontal-mono-white.svg` | Una tinta blanca sobre cualquier fondo oscuro |
| `logo-mark.svg`, `-dark`, `-mono`, `-mono-white` | Símbolo solo (avatar, favicon, app) |
| `icon-32/180/192/512.png` | Favicon, Apple touch, PWA |
| `construccion.svg` | Zona de protección y tamaños mínimos |

Para regenerarlos: `npm run brand`. Los SVG son los másteres y los PNG se exportan desde ellos.

### Construcción

- Retícula del símbolo: 120 × 120 u, radio de esquina 27 u. La P usa un trazo de 12 u y la trayectoria uno de 8 u, ambos con remates redondos.
- **Zona de protección:** 30 u, es decir, 1/4 del ancho del símbolo, en los cuatro lados. Ningún texto, borde ni imagen entra en ella.
- **Tamaño mínimo:** símbolo 32 px (digital) o 8 mm (impreso); logotipo horizontal 180 px o 45 mm de ancho.
- El símbolo solo se usa sin el nombre cuando la marca completa ya aparece en la misma pieza o en el contexto: favicon, avatar de perfil.

### Paleta y contraste (WCAG 2.1, medido)

| Token | Hex | Rol | Contraste verificado |
| --- | --- | --- | --- |
| `navy` | `#102A43` | Fondo de marca, texto principal | 14.6:1 sobre blanco |
| `mint` | `#72E3B2` | Acento y CTA sobre oscuro | 9.3:1 sobre `navy` |
| `teal` | `#127C70` | Enlaces, acciones y cambio positivo sobre claro | 5.1:1 sobre blanco · 4.7:1 sobre `#F3F6F8` |
| `tealDark` | `#0B5147` | Trazo sobre mint, texto sobre mint claro | 5.9:1 sobre `mint` |
| `muted` | `#526B7F` | Texto secundario | 5.6:1 sobre blanco |
| `loss` | `#A04F4A` | Cambio negativo, alertas | 5.7:1 sobre blanco |
| `bg` / `paper` | `#F3F6F8` / `#F5F8FA` | Superficies | n/a |
| `navy2` | `#163A54` | Ola secundaria en piezas oscuras | `#DCE7EE` encima: 9.5:1 |

El color nunca es el único portador del significado. Todo cambio lleva signo explícito (+ o −) y una palabra que lo explique ("debes menos", "es gasto").

### Tipografía

Arial y Helvetica, sin fuentes web: es rápido, privado (no hay peticiones a terceros) y está disponible en todas partes. Las cifras usan `font-variant-numeric: tabular-nums` en tablas.

| Nivel | Tamaño | Peso |
| --- | --- | --- |
| Cifra principal (patrimonio) | 48–56 px | Bold |
| H1 | 32–40 px | Bold |
| H2 | 22–28 px | Bold |
| Cuerpo | 16–18 px | Regular |
| Etiqueta | 14–16 px | Regular o Bold |
| Legal / nota | 13–14 px (nunca menos de 12) | Regular |

### Componentes (app)

- **Tarjeta de cifra:** etiqueta arriba, cifra, y debajo el cambio con signo y el mes de referencia. Radio 16 px, borde `#E2E8F0`.
- **Fila de explicación:** concepto a la izquierda con una nota de una línea debajo; importe con signo a la derecha. La fila de resultado va separada por una línea.
- **Aviso:** icono, frase del hecho y acción. Hay tres tonos: información (`teal`), falta de datos (`muted`) y riesgo (`loss`). Usa `role="status"` para lo informativo y `role="alert"` para los errores.
- **Campo de importe:** etiqueta persistente, prefijo `$` y un marcador "Sin registrar" en los campos opcionales. Un campo vacío nunca se convierte en 0.
- **Botón primario:** `navy` sobre claro y `mint` con texto `navy` sobre oscuro. Altura mínima de 44 px.

### Iconografía

- Lucide (la que ya usa la app), con trazo de 2 px, esquinas redondeadas y tamaño de 16/20/24 px.
- Un icono acompaña siempre a una etiqueta de texto; nunca la sustituye. La excepción son los botones de editar y eliminar, que llevan `aria-label`.
- Flechas solo para dirección de cambio. No se usan cohetes, monedas cayendo, trofeos ni otros iconos de "ganar".

### Voz: ejemplos correctos e incorrectos

| ✅ Sí | ❌ No | Por qué |
| --- | --- | --- |
| «Tu patrimonio subió $500: banco −$500 y deuda −$1,000.» | «¡Ganaste $1,000 pagando deuda!» | El pago de capital no crea riqueza; mueve valor. |
| «Inversiones +$300. Incluye aportes y cambios de mercado; registra tus aportes para separarlos.» | «Tus inversiones se apreciaron $300.» | Sin transacciones no se sabe la causa. |
| «Faltan datos de ingresos para calcular este indicador.» | «Liquidez: 0 %» | Un dato vacío no es cero. |
| «Entre enero y marzo (faltan los datos de febrero).» | «Cambio del mes: +$400» | Oculta el hueco. |
| «Con esta cuota, el saldo no baja: la cuota ($350) es menor que el interés ($400).» | «Liquidación: nunca 😬» | Hay que explicar el hecho, sin juicio. |
| «Liquidación estimada: 41 meses si la tasa y la cuota no cambian.» | «Estarás libre de deudas en 2030.» | Una estimación no es una promesa. |
| «Ejemplo ilustrativo.» en toda pieza con cifras inventadas | Cifras sin aviso | Transparencia. |

## Especificación UX por pantalla (v2)

Cada pantalla resuelve una tarea. Los cálculos vienen de `lib/finance/engine.ts`.

| Pantalla | Tarea | Estados obligatorios | Funciones del motor |
| --- | --- | --- | --- |
| Incorporación (3 pasos) | Registrar el primer cierre: saldos, luego flujo (opcional), luego el siguiente mes | vacío, guardando, error recuperable | `netWorth` |
| Resumen | Saber cuánto tengo, cuánto debo y el cambio | 0, 1, 2+ cierres; patrimonio negativo; hueco de meses | `explainChange`, `missingMonths` |
| ¿Qué cambió? | Ver la explicación del cambio línea a línea | deuda aumentó; capital declarado ≠ baja de deuda; inversiones mixtas | `explainChange().notices` |
| Flujo del mes | Ver ingresos − consumo − intereses y la asignación | "Sin registrar" por campo; flujo no conciliado | `monthFlow` |
| Indicadores | Consultar seis ratios con definición visible | "Falta: …" o "división imposible" por ratio | `ratios` |
| Comparación temporal | Comparar dos cierres cualesquiera | hueco de meses; cruce de signo | `explainChange(a,b)` |
| Préstamos | Separar interés y capital de la próxima cuota | no amortiza; saldo cero; APR 0 | `splitPayment`, `projectPayoff` |
| Cuentas y transacciones (nuevo) | Registrar movimientos con fecha y fuente, y conciliar | cuenta sin conciliar; importe "sin explicar" | `explainWithLedger`, `aggregateBalances` |
| Metas | Ver el avance hacia una meta propia | sin meta; patrimonio negativo (0 %) | `goalProgress` |

Accesibilidad: navegación completa con teclado, foco visible (anillo `teal` de 3 px), etiquetas persistentes, `aria-live` para guardar y errores, objetivos táctiles de 44 px, sin información solo por color y moneda explícita (USD).

## Sistema social

Todo el contenido está en `brand/content/posts.json` y `npm run brand` lo exporta a `brand/social/<id>/{1x1,4x5,9x16}.{svg,png}`. El generador:

1. Verifica cada cifra con el motor (por ejemplo, que −$500 y −$1,000 den +$500). Si no cuadra, el build falla.
2. Reduce el titular hasta que quepa y falla si el cuerpo no cabe, así que no hay texto recortado.
3. Añade «Ejemplo ilustrativo» en todas las piezas.

Los captions y el texto alternativo están en `brand/social/CAPTIONS.md`. La CTA es «Guarda esta explicación»: no invita a registrarse, porque la app es privada y no hay conexión bancaria.

---

## Versión 1 (referencia)

## Propuesta

**Promesa:** entiende qué cambió en tu patrimonio cada mes y por qué.

**Público inicial:** personas y familias que administran efectivo, inversiones y deudas, pero no tienen una explicación clara de su situación financiera completa.

**Idea de marca:** claridad sin juicio. La plataforma traduce un balance personal a decisiones comprensibles, sin fingir certeza cuando faltan datos.

**Mensaje principal:** «Tu balance tiene una historia. Entiende qué cambió y por qué».

**Uso del nombre:** Patrimonio CFO. «CFO» identifica el enfoque de dirección financiera personal, pero la comunicación cotidiana usa «patrimonio», «dinero disponible», «deuda» y «cambio del mes».

## Identidad visual

| Elemento | Valor | Uso |
| --- | --- | --- |
| Azul profundidad | `#102A43` | Fondo de marca, encabezados, datos principales |
| Verde claridad | `#72E3B2` | Mejora y llamada principal sobre fondo oscuro |
| Verde análisis | `#127C70` | Acciones, enlaces y números positivos sobre fondo claro |
| Fondo | `#F3F6F8` | Superficie general |
| Blanco | `#FFFFFF` | Tarjetas y formularios |
| Texto secundario | `#526B7F` | Contexto y etiquetas |
| Pérdida/advertencia | `#A04F4A` | Cambios negativos y alertas; nunca solo mediante color |

**Tipografía:** Arial/Helvetica para una implementación portable. Jerarquía: título 36–48 px, subtítulos 22–28 px, cuerpo 16–18 px, etiquetas 14–16 px. Tablas y cifras con números tabulares cuando estén disponibles.

**Símbolo:** la P construye un contenedor de patrimonio; la trayectoria verde representa evolución. No implica que todo cambio sea positivo. El icono puede usarse sin el nombre solo después de que la marca aparezca completa en la misma pieza.

**Archivos:** `public/brand/logo-mark.svg`, `public/brand/logo-horizontal.svg`, `public/brand/logo-horizontal-dark.svg` para fondo oscuro y `public/brand/logo-mark-mono.svg` para reproducción a un color. Reserva alrededor del símbolo un área mínima equivalente a 1/4 de su ancho. Tamaño mínimo de icono 32 px digital; logotipo horizontal 180 px. No estirar, sombrear, cambiar los colores por gradientes ni usar verde como único indicador de ganancia.

## Lenguaje

- Voz: precisa, tranquila, directa. Explica el hecho, la causa verificable y el dato faltante.
- Sí: «Tu patrimonio subió $500: banco −$500 y deuda −$1,000».
- No: «Ganaste $1,000 pagando tu deuda»; el pago de capital reduce efectivo y deuda en igual importe.
- Sí: «El valor de inversiones subió $300; incluye aportes y variaciones de mercado» hasta que existan datos para separarlos.
- No usar diagnósticos como «estás sano financieramente» por un ratio aislado.
- Toda pieza con cifras inventadas lleva «Ejemplo ilustrativo».

## Sistema UX/UI

**Primera vista:** patrimonio del mes seleccionado; diferencia frente al cierre anterior; efectivo, activos y deudas; desglose exacto; flujo del mes; seis indicadores. El usuario puede cambiar el mes y revisar el historial.

**Flujo de incorporación:** (1) registrar efectivo, inversiones, otros activos y deuda al final de un mes; (2) completar ingresos, consumo, intereses y pagos de capital si los conoce; (3) registrar otro mes; (4) leer el cambio. Los campos de flujo desconocidos quedan vacíos, nunca en cero automáticamente.

**Modelo de certeza:** saldo confirmado / cifra introducida por la persona / proyección. El saldo de cierre explica el cambio contable; los movimientos de flujo siguen sin conciliarse con bancos. No atribuir «apreciación» ni «ahorro» automáticamente a un cambio agregado de inversiones o efectivo.

**Deudas:** saldo, APR, cuota; siguiente pago separa interés y capital. Si la cuota no cubre interés, informar «no amortiza». Fecha de liquidación es estimada, no una promesa.

**Estados:** sin datos, un mes, dos o más meses, guardando, guardado, error recuperable, falta información, división imposible, deuda no amortizable, patrimonio negativo. Formularios accesibles por teclado, etiquetas persistentes, foco visible, contraste suficiente y formato de moneda explícito.

**Navegación:** Resumen / Cierres mensuales / Préstamos. Las metas figuran en el cierre mensual y muestran avance sin recomendar una cifra universal.

## Piezas de lanzamiento

| Archivo | Formato | Idea | Copy/caption sugerido |
| --- | --- | --- | --- |
| `post-01-square.svg` | 1080×1080 | Banco baja, patrimonio sube | «El saldo del banco no cuenta toda la historia. Mira activos y deudas juntos. Ejemplo ilustrativo.» |
| `post-02-portrait.svg` | 1080×1350 | Separar interés y capital | «Una cuota puede ser gasto y reducción de deuda a la vez. Patrimonio CFO te muestra cada parte.» |
| `post-03-story.svg` | 1080×1920 | Resultado y explicación | «¿Sabes por qué cambió tu patrimonio este mes? Descubre la historia detrás de tus saldos.» |

**CTA común:** «Conoce tu patrimonio». Estas piezas son material de lanzamiento; la aplicación sigue privada y no debe anunciarse como acceso público hasta habilitarlo. No afirmar conexión bancaria ni automatización todavía. Los ejemplos son ilustrativos. Exportar PNG a resolución nativa para redes, conservando los SVG como másteres editables.

## Próxima evolución del producto

1. Cuentas y activos individuales con fecha, fuente y tipo, conservando el balance agregado.
2. Registro de transacciones e importación CSV; conciliación entre movimientos y saldos antes de explicar causas específicas.
3. Obligaciones con intereses variables, cargos, nuevas disposiciones y ajustes, con agenda de amortización verificable.
4. Metas por hogar, múltiples miembros y permisos explícitos.
5. Integración bancaria solo con proveedor adecuado, permisos revocables, consentimiento y controles de seguridad verificados.

El nombre y la marca son dirección creativa actual; revisar disponibilidad legal y de dominio antes de registrarlos o invertir en campaña pagada.
