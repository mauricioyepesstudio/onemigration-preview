import { test } from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";

// D1 es SQLite: validamos la migración contra SQLite local con claves foráneas activas.
const sql = readFileSync(new URL("../../db/migrations/0002_accounts_ledger.sql", import.meta.url), "utf8");

function db() {
  const d = new DatabaseSync(":memory:");
  d.exec("PRAGMA foreign_keys = ON;");
  // Tabla existente simulada: la migración no debe tocarla.
  d.exec("CREATE TABLE months (user_id TEXT, month TEXT, cash INTEGER); INSERT INTO months VALUES ('u1','2026-08',100);");
  d.exec(sql);
  d.exec("INSERT INTO accounts (id,user_id,name,kind) VALUES ('bank','u1','Banco','cash'),('car','u1','Auto','liability');");
  return d;
}

test("la migración es aditiva e idempotente", () => {
  const d = db();
  d.exec(sql); // segunda aplicación sin error
  assert.deepEqual({ ...d.prepare("SELECT * FROM months").get() }, { user_id: "u1", month: "2026-08", cash: 100 });
});

test("restricciones: montos, tipos y cuenta destino", () => {
  const d = db();
  const ins = d.prepare("INSERT INTO transactions (id,user_id,occurred_on,kind,amount,account_id,counter_account_id,source) VALUES (?,?,?,?,?,?,?,?)");
  ins.run("t1", "u1", "2026-08-05", "principal_payment", 20000, "bank", "car", "manual");
  ins.run("t2", "u1", "2026-08-31", "valuation", -5000, "car", null, "manual");
  assert.throws(() => ins.run("t3", "u1", "2026-08-05", "expense", -100, "bank", null, "manual"));
  assert.throws(() => ins.run("t4", "u1", "2026-08-05", "principal_payment", 100, "bank", null, "manual"));
  assert.throws(() => ins.run("t5", "u1", "2026-08-05", "transfer", 100, "bank", "bank", "manual"));
  assert.throws(() => ins.run("t6", "u1", "2026-08-05", "expense", 100, "bank", "car", "manual"));
  assert.throws(() => ins.run("t7", "u1", "08/05/2026", "expense", 100, "bank", null, "manual"));
  assert.throws(() => ins.run("t8", "u1", "2026-08-05", "expense", 100, "nope", null, "manual"));
  assert.throws(() => d.exec("DELETE FROM accounts WHERE id='bank'")); // el historial no se borra en cascada
});

test("deduplicación de importaciones CSV por fuente y referencia", () => {
  const d = db();
  const ins = d.prepare("INSERT INTO transactions (id,user_id,occurred_on,kind,amount,account_id,source,source_ref) VALUES (?,?,?,?,?,?,?,?)");
  ins.run("a", "u1", "2026-08-01", "income", 500000, "bank", "csv", "chase-2026-08#12");
  assert.throws(() => ins.run("b", "u1", "2026-08-01", "income", 500000, "bank", "csv", "chase-2026-08#12"));
});
