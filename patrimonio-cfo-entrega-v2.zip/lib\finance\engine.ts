// Motor de cálculo de Patrimonio CFO.
// Todos los importes son centavos enteros (USD). Los campos de flujo `null` significan
// "sin registrar" y nunca se tratan como cero.
// Los tipos MonthClose y Loan replican el contrato actual de /api/finance y /api/loans.

export type Cents = number;

export interface MonthClose {
  month: string; // YYYY-MM
  cash: Cents;
  investments: Cents;
  otherAssets: Cents;
  debt: Cents;
  income: Cents | null;
  living: Cents | null;
  interest: Cents | null;
  principal: Cents | null;
  contributions: Cents | null;
  housing: Cents | null;
  goal: Cents | null;
}

export interface Loan {
  id: string;
  name: string;
  balance: Cents;
  aprBps: number; // 650 = 6.50 % APR
  payment: Cents;
}

// ---------- Balance ----------

export const totalAssets = (m: MonthClose): Cents => m.cash + m.investments + m.otherAssets;
export const netWorth = (m: MonthClose): Cents => totalAssets(m) - m.debt;

const MONTH_RE = /^\d{4}-(0[1-9]|1[0-2])$/;

export function monthIndex(month: string): number {
  if (!MONTH_RE.test(month)) throw new Error(`Mes inválido: ${month}`);
  const [y, m] = month.split("-").map(Number);
  return y * 12 + (m - 1);
}

export function monthsBetween(from: string, to: string): number {
  return monthIndex(to) - monthIndex(from);
}

/** Meses sin cierre entre el primer y el último cierre registrado. */
export function missingMonths(months: string[]): string[] {
  if (months.length < 2) return [];
  const idx = [...new Set(months.map(monthIndex))].sort((a, b) => a - b);
  const have = new Set(idx);
  const out: string[] = [];
  for (let i = idx[0]; i <= idx[idx.length - 1]; i++) {
    if (!have.has(i)) out.push(`${Math.floor(i / 12)}-${String((i % 12) + 1).padStart(2, "0")}`);
  }
  return out;
}

// ---------- Explicación del cambio entre dos cierres ----------

export type Notice =
  | { code: "gap"; months: number }
  | { code: "debt_increased"; amount: Cents }
  | { code: "principal_exceeds_debt_drop"; declared: Cents; debtDrop: Cents }
  | { code: "principal_below_debt_drop"; declared: Cents; debtDrop: Cents }
  | { code: "investments_mixed"; amount: Cents }
  | { code: "negative_net_worth"; amount: Cents }
  | { code: "unexplained"; amount: Cents };

export interface ChangeExplanation {
  from: string;
  to: string;
  spanMonths: number;
  cash: Cents;
  investments: Cents;
  otherAssets: Cents;
  /** Cambio en saldo de deuda (positivo = deuda aumentó). */
  debt: Cents;
  netWorth: Cents;
  /** Siempre 0: Δactivos − Δdeuda = Δpatrimonio. Se expone para auditar. */
  reconciliationError: Cents;
  notices: Notice[];
}

/**
 * Explica el cambio de patrimonio solo con saldos. No atribuye apreciación, ahorro ni
 * aportes: eso requiere transacciones (ver explainWithLedger).
 */
export function explainChange(prev: MonthClose, curr: MonthClose): ChangeExplanation {
  const spanMonths = monthsBetween(prev.month, curr.month);
  if (spanMonths <= 0) throw new Error("El cierre anterior debe ser de un mes previo.");
  const cash = curr.cash - prev.cash;
  const investments = curr.investments - prev.investments;
  const otherAssets = curr.otherAssets - prev.otherAssets;
  const debt = curr.debt - prev.debt;
  const nw = netWorth(curr) - netWorth(prev);
  const notices: Notice[] = [];

  if (spanMonths > 1) notices.push({ code: "gap", months: spanMonths - 1 });
  if (debt > 0) notices.push({ code: "debt_increased", amount: debt });
  if (curr.principal !== null && spanMonths === 1) {
    const drop = -debt;
    if (curr.principal > drop) notices.push({ code: "principal_exceeds_debt_drop", declared: curr.principal, debtDrop: drop });
    if (curr.principal < drop) notices.push({ code: "principal_below_debt_drop", declared: curr.principal, debtDrop: drop });
  }
  if (investments !== 0) notices.push({ code: "investments_mixed", amount: investments });
  if (netWorth(curr) < 0) notices.push({ code: "negative_net_worth", amount: netWorth(curr) });

  return {
    from: prev.month,
    to: curr.month,
    spanMonths,
    cash,
    investments,
    otherAssets,
    debt,
    netWorth: nw,
    reconciliationError: cash + investments + otherAssets - debt - nw,
    notices,
  };
}

// ---------- Flujo del mes ----------

export interface MonthFlow {
  /** Ingresos − consumo − intereses. null si falta cualquiera de los tres. */
  freeCashFlow: Cents | null;
  /** Flujo libre − capital pagado − aportes. null si falta algún dato. */
  unallocated: Cents | null;
}

export function monthFlow(m: MonthClose): MonthFlow {
  const free = m.income !== null && m.living !== null && m.interest !== null ? m.income - m.living - m.interest : null;
  const unallocated = free !== null && m.principal !== null && m.contributions !== null ? free - m.principal - m.contributions : null;
  return { freeCashFlow: free, unallocated };
}

// ---------- Seis indicadores ----------

export type RatioId = "liquidity" | "debtToAssets" | "debtService" | "freeCashFlowRate" | "housing" | "netWorthGrowth";

export interface Ratio {
  id: RatioId;
  label: string;
  definition: string;
  unit: "months" | "percent";
  /** Valor numérico (meses o porcentaje 0–100+). null si no se puede calcular. */
  value: number | null;
  /** Motivo cuando value es null. */
  missing?: string;
}

const pct = (n: number, d: number) => (n / d) * 100;

export function ratios(curr: MonthClose, prev?: MonthClose): Ratio[] {
  const need = (fields: (keyof MonthClose)[]) => fields.filter((f) => curr[f] === null);
  const out: Ratio[] = [];

  const monthlyNeeds = curr.living !== null && curr.interest !== null ? curr.living + curr.interest : null;
  out.push({
    id: "liquidity",
    label: "Liquidez",
    definition: "Banco y efectivo ÷ (consumo + intereses del mes). Meses que podrías cubrir sin nuevos ingresos.",
    unit: "months",
    value: monthlyNeeds && monthlyNeeds > 0 ? curr.cash / monthlyNeeds : null,
    missing: monthlyNeeds === null ? `Falta: ${need(["living", "interest"]).join(", ")}` : monthlyNeeds === 0 ? "Consumo e intereses son $0: división imposible" : undefined,
  });

  const assets = totalAssets(curr);
  out.push({
    id: "debtToAssets",
    label: "Deuda / activos",
    definition: "Deuda total ÷ activos totales. Sobre 100 % significa que debes más de lo que tienes.",
    unit: "percent",
    value: assets > 0 ? pct(curr.debt, assets) : null,
    missing: assets > 0 ? undefined : "Activos en $0: división imposible",
  });

  const svc = curr.principal !== null && curr.interest !== null && curr.income !== null && curr.income > 0;
  out.push({
    id: "debtService",
    label: "Servicio de deuda / ingresos",
    definition: "(Capital + intereses pagados) ÷ ingresos del mes.",
    unit: "percent",
    value: svc ? pct(curr.principal! + curr.interest!, curr.income!) : null,
    missing: svc ? undefined : curr.income === 0 ? "Ingresos en $0: división imposible" : `Falta: ${need(["principal", "interest", "income"]).join(", ")}`,
  });

  const flow = monthFlow(curr).freeCashFlow;
  out.push({
    id: "freeCashFlowRate",
    label: "Flujo disponible / ingresos",
    definition: "(Ingresos − consumo − intereses) ÷ ingresos. Lo que quedó para pagar capital, invertir o ahorrar.",
    unit: "percent",
    value: flow !== null && curr.income! > 0 ? pct(flow, curr.income!) : null,
    missing: flow === null ? `Falta: ${need(["income", "living", "interest"]).join(", ")}` : curr.income === 0 ? "Ingresos en $0: división imposible" : undefined,
  });

  const hs = curr.housing !== null && curr.income !== null && curr.income > 0;
  out.push({
    id: "housing",
    label: "Vivienda / ingresos",
    definition: "Gasto de vivienda (renta o hipoteca completa) ÷ ingresos del mes.",
    unit: "percent",
    value: hs ? pct(curr.housing!, curr.income!) : null,
    missing: hs ? undefined : curr.income === 0 ? "Ingresos en $0: división imposible" : `Falta: ${need(["housing", "income"]).join(", ")}`,
  });

  let growth: number | null = null;
  let growthMissing: string | undefined;
  if (!prev) growthMissing = "Necesita un cierre anterior";
  else if (netWorth(prev) <= 0) growthMissing = "El patrimonio anterior es $0 o negativo: el porcentaje no es interpretable; usa el cambio en dólares";
  else if (monthsBetween(prev.month, curr.month) !== 1) growthMissing = "Hay meses sin cierre entre ambos periodos; se muestra solo el cambio en dólares";
  else growth = pct(netWorth(curr) - netWorth(prev), netWorth(prev));
  out.push({
    id: "netWorthGrowth",
    label: "Crecimiento patrimonial",
    definition: "Cambio de patrimonio ÷ patrimonio del mes anterior. Solo entre meses consecutivos y con base positiva.",
    unit: "percent",
    value: growth,
    missing: growthMissing,
  });

  return out;
}

/** Progreso hacia una meta de patrimonio, 0–100. null si no hay meta válida. */
export function goalProgress(m: MonthClose): number | null {
  if (m.goal === null || m.goal <= 0) return null;
  return Math.min(100, Math.max(0, pct(netWorth(m), m.goal)));
}

// ---------- Préstamos ----------

/** Interés de un mes con APR fija, redondeado al centavo. */
export const monthlyInterest = (balance: Cents, aprBps: number): Cents => Math.round((balance * aprBps) / 120_000);

export interface PaymentSplit {
  interest: Cents;
  principal: Cents;
  /** true si la cuota no cubre el interés: el saldo no baja. */
  nonAmortizing: boolean;
  /** Interés no cubierto por la cuota (se suma al saldo si el prestamista lo capitaliza). */
  shortfall: Cents;
}

export function splitPayment(balance: Cents, aprBps: number, payment: Cents): PaymentSplit {
  const interest = monthlyInterest(balance, aprBps);
  if (payment <= interest) {
    return { interest: Math.min(interest, payment), principal: 0, nonAmortizing: true, shortfall: interest - payment };
  }
  return { interest, principal: Math.min(balance, payment - interest), nonAmortizing: false, shortfall: 0 };
}

export interface Payoff {
  months: number | null;
  totalInterest: Cents | null;
}

export function projectPayoff(loan: Pick<Loan, "balance" | "aprBps" | "payment">, maxMonths = 1200): Payoff {
  let bal = loan.balance;
  let totalInterest = 0;
  let n = 0;
  if (bal <= 0) return { months: 0, totalInterest: 0 };
  while (bal > 0 && n < maxMonths) {
    const s = splitPayment(bal, loan.aprBps, loan.payment);
    if (s.nonAmortizing) return { months: null, totalInterest: null };
    totalInterest += s.interest;
    bal -= s.principal;
    n++;
  }
  return bal <= 0 ? { months: n, totalInterest } : { months: null, totalInterest: null };
}

// ---------- Libro de transacciones (modelo extendido, migración 0002) ----------

export type AccountKind = "cash" | "investment" | "other_asset" | "liability";

export interface Account {
  id: string;
  name: string;
  kind: AccountKind;
}

/**
 * Tipos de transacción. Cada una mueve saldos de cuentas con un signo explícito.
 * - income / expense / interest: afectan el patrimonio.
 * - transfer / principal_payment / contribution: mueven valor entre cuentas propias; patrimonio neutro.
 * - borrowing: entra efectivo o activo y sube la deuda en igual importe; patrimonio neutro.
 * - valuation: apreciación (+) o depreciación (−) declarada con fuente.
 * - adjustment: corrección sin causa conocida; se reporta aparte.
 */
export type TxKind = "income" | "expense" | "interest" | "transfer" | "principal_payment" | "contribution" | "borrowing" | "valuation" | "adjustment";

export interface Transaction {
  id: string;
  date: string; // YYYY-MM-DD
  kind: TxKind;
  amount: Cents; // siempre positivo, salvo valuation/adjustment que llevan signo
  accountId: string; // cuenta origen (o cuenta afectada)
  counterAccountId?: string | null; // destino en transfer / principal_payment / contribution / borrowing
  source: "manual" | "csv" | "statement";
  description?: string;
}

/** Efecto de una transacción sobre el saldo de cada cuenta. Pasivos: + = deuda sube. */
export function txEffects(tx: Transaction): Map<string, Cents> {
  const e = new Map<string, Cents>();
  const add = (id: string, v: Cents) => e.set(id, (e.get(id) ?? 0) + v);
  const a = tx.amount;
  if ((tx.kind !== "valuation" && tx.kind !== "adjustment") && a < 0) throw new Error(`Importe negativo en ${tx.id}`);
  switch (tx.kind) {
    case "income": add(tx.accountId, a); break;
    case "expense":
    case "interest": add(tx.accountId, -a); break; // pagado desde un activo; si se carga a tarjeta, accountId es el pasivo y ver abajo
    case "transfer":
    case "contribution": add(tx.accountId, -a); add(req(tx), a); break;
    case "principal_payment": add(tx.accountId, -a); add(req(tx), -a); break; // baja activo y baja deuda
    case "borrowing": add(tx.accountId, a); add(req(tx), a); break; // sube activo y sube deuda
    case "valuation":
    case "adjustment": add(tx.accountId, a); break;
  }
  return e;
}

function req(tx: Transaction): string {
  if (!tx.counterAccountId) throw new Error(`La transacción ${tx.id} (${tx.kind}) necesita cuenta destino`);
  return tx.counterAccountId;
}

export interface LedgerExplanation {
  byKind: Record<TxKind, Cents>; // efecto en patrimonio por tipo
  explained: Cents;
  unexplained: Cents; // diferencia de saldos no respaldada por transacciones
  netWorthChange: Cents;
  accountsUnreconciled: { accountId: string; expected: Cents; actual: Cents }[];
}

/**
 * Concilia saldos de apertura y cierre por cuenta contra las transacciones del periodo.
 * La porción no respaldada se reporta como "sin explicar"; nunca se atribuye a
 * apreciación, ahorro o aportes.
 */
export function explainWithLedger(
  accounts: Account[],
  opening: Record<string, Cents>,
  closing: Record<string, Cents>,
  txs: Transaction[],
): LedgerExplanation {
  const kindOf = new Map(accounts.map((a) => [a.id, a.kind]));
  const sign = (id: string) => {
    const k = kindOf.get(id);
    if (!k) throw new Error(`Cuenta desconocida: ${id}`);
    return k === "liability" ? -1 : 1;
  };
  const byKind = Object.fromEntries(
    (["income", "expense", "interest", "transfer", "principal_payment", "contribution", "borrowing", "valuation", "adjustment"] as TxKind[]).map((k) => [k, 0]),
  ) as Record<TxKind, Cents>;
  const expectedDelta = new Map<string, Cents>();
  for (const tx of txs) {
    let nwEffect = 0;
    for (const [id, v] of txEffects(tx)) {
      // expense/interest cargados a un pasivo (tarjeta): la deuda sube.
      const eff = (tx.kind === "expense" || tx.kind === "interest") && kindOf.get(id) === "liability" ? -v : v;
      expectedDelta.set(id, (expectedDelta.get(id) ?? 0) + eff);
      nwEffect += sign(id) * eff;
    }
    byKind[tx.kind] += nwEffect;
  }
  const nwOf = (bal: Record<string, Cents>) => accounts.reduce((s, a) => s + sign(a.id) * (bal[a.id] ?? 0), 0);
  const netWorthChange = nwOf(closing) - nwOf(opening);
  const explained = Object.values(byKind).reduce((s, v) => s + v, 0);
  const accountsUnreconciled = accounts
    .map((a) => ({ accountId: a.id, expected: (opening[a.id] ?? 0) + (expectedDelta.get(a.id) ?? 0), actual: closing[a.id] ?? 0 }))
    .filter((r) => r.expected !== r.actual);
  return { byKind, explained, unexplained: netWorthChange - explained, netWorthChange, accountsUnreconciled };
}

/** Suma saldos por tipo de cuenta para compararlos con el cierre mensual agregado. */
export function aggregateBalances(accounts: Account[], balances: Record<string, Cents>) {
  const agg = { cash: 0, investments: 0, otherAssets: 0, debt: 0 };
  for (const a of accounts) {
    const v = balances[a.id] ?? 0;
    if (a.kind === "cash") agg.cash += v;
    else if (a.kind === "investment") agg.investments += v;
    else if (a.kind === "other_asset") agg.otherAssets += v;
    else agg.debt += v;
  }
  return agg;
}
