-- 0002 · Cuentas, saldos por cuenta y transacciones con fuente y fecha.
-- Migración ADITIVA: no modifica ni borra tablas existentes (cierres mensuales y préstamos).
-- Los cierres mensuales siguen siendo la fuente del balance agregado; estas tablas lo
-- desglosan y permiten conciliar. Importes en centavos enteros (USD).
--
-- ANTES DE APLICAR: sustituir `user_id TEXT` por el tipo/nombre de la columna de usuario
-- que usan las tablas actuales en db/schema.ts, y aplicar el mismo filtro de acceso por
-- usuario en cada consulta (WHERE user_id = ?). No se crean vistas ni permisos nuevos.

CREATE TABLE IF NOT EXISTS accounts (
  id            TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL,
  name          TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 80),
  kind          TEXT NOT NULL CHECK (kind IN ('cash','investment','other_asset','liability')),
  institution   TEXT,                       -- texto libre; sin credenciales bancarias
  loan_id       TEXT,                       -- enlace opcional a un préstamo existente
  opened_on     TEXT CHECK (opened_on IS NULL OR opened_on GLOB '[0-9][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]'),
  closed_on     TEXT CHECK (closed_on IS NULL OR closed_on GLOB '[0-9][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]'),
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS accounts_user_idx ON accounts(user_id);

-- Saldo de una cuenta en una fecha, con su fuente y nivel de certeza.
CREATE TABLE IF NOT EXISTS account_balances (
  id            TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL,
  account_id    TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  as_of         TEXT NOT NULL CHECK (as_of GLOB '[0-9][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]'),
  balance       INTEGER NOT NULL CHECK (balance >= 0 AND balance <= 1000000000000),
  source        TEXT NOT NULL CHECK (source IN ('manual','statement','csv')),
  certainty     TEXT NOT NULL DEFAULT 'entered' CHECK (certainty IN ('confirmed','entered','projected')),
  note          TEXT,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (account_id, as_of)
);
CREATE INDEX IF NOT EXISTS account_balances_user_date_idx ON account_balances(user_id, as_of);

-- Transacciones. amount > 0 salvo valuation/adjustment (con signo).
-- Semántica en lib/finance/engine.ts (txEffects / explainWithLedger).
CREATE TABLE IF NOT EXISTS transactions (
  id                 TEXT PRIMARY KEY,
  user_id            TEXT NOT NULL,
  occurred_on        TEXT NOT NULL CHECK (occurred_on GLOB '[0-9][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]'),
  kind               TEXT NOT NULL CHECK (kind IN ('income','expense','interest','transfer','principal_payment','contribution','borrowing','valuation','adjustment')),
  amount             INTEGER NOT NULL CHECK (
                       abs(amount) <= 1000000000000 AND
                       (kind IN ('valuation','adjustment') OR amount > 0)),
  account_id         TEXT NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
  counter_account_id TEXT REFERENCES accounts(id) ON DELETE RESTRICT,
  source             TEXT NOT NULL CHECK (source IN ('manual','csv','statement')),
  source_ref         TEXT,                  -- nº de línea CSV o id de extracto, para deduplicar
  description        TEXT,
  created_at         TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  CHECK (
    (kind IN ('transfer','principal_payment','contribution','borrowing') AND counter_account_id IS NOT NULL AND counter_account_id <> account_id)
    OR (kind NOT IN ('transfer','principal_payment','contribution','borrowing') AND counter_account_id IS NULL)
  )
);
CREATE INDEX IF NOT EXISTS transactions_user_date_idx ON transactions(user_id, occurred_on);
CREATE UNIQUE INDEX IF NOT EXISTS transactions_dedupe_idx ON transactions(user_id, source, source_ref) WHERE source_ref IS NOT NULL;

-- Rollback (solo si no hay datos que conservar):
-- DROP TABLE transactions; DROP TABLE account_balances; DROP TABLE accounts;
