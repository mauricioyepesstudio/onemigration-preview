// Genera los activos de marca y las piezas sociales de Patrimonio CFO.
//   node scripts/build-brand.mjs
// Fuentes: Arial / Arial Bold del sistema (definidas en la guía de identidad).
// Salida: public/brand/*.svg|png y brand/social/<post>/<formato>.svg|png
import { mkdirSync, readFileSync, writeFileSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import opentype from "opentype.js";
import { Resvg } from "@resvg/resvg-js";
import { explainChange, splitPayment } from "../lib/finance/engine.ts";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const FONT_DIR = process.env.FONT_DIR ?? "C:/Windows/Fonts";
const REG = join(FONT_DIR, "arial.ttf");
const BOLD = join(FONT_DIR, "arialbd.ttf");
for (const f of [REG, BOLD]) if (!existsSync(f)) throw new Error(`Falta la fuente ${f}. Define FONT_DIR.`);
const bold = opentype.loadSync(BOLD);
const reg = opentype.loadSync(REG);

export const C = {
  navy: "#102A43", navy2: "#163A54", mint: "#72E3B2", teal: "#127C70", tealDark: "#0B5147",
  bg: "#F3F6F8", paper: "#F5F8FA", white: "#FFFFFF", muted: "#526B7F", loss: "#A04F4A", line: "#D6E1E8", mist: "#BDD0DA",
};

// ---------- utilidades tipográficas ----------
function measure(font, text, size, tracking = 0) {
  let w = 0;
  const glyphs = font.stringToGlyphs(text);
  glyphs.forEach((g, i) => {
    w += (g.advanceWidth * size) / font.unitsPerEm;
    if (i < glyphs.length - 1) w += (font.getKerningValue(g, glyphs[i + 1]) * size) / font.unitsPerEm + tracking;
  });
  return w;
}
function outline(font, text, x, y, size, tracking = 0) {
  const glyphs = font.stringToGlyphs(text);
  let cx = x;
  const parts = [];
  glyphs.forEach((g, i) => {
    parts.push(g.getPath(cx, y, size).toPathData(2));
    cx += (g.advanceWidth * size) / font.unitsPerEm;
    if (i < glyphs.length - 1) cx += (font.getKerningValue(g, glyphs[i + 1]) * size) / font.unitsPerEm + tracking;
  });
  return { d: parts.join(""), width: cx - x };
}
function wrap(font, text, size, maxW) {
  const words = text.split(" ");
  const lines = [];
  let cur = "";
  for (const w of words) {
    const t = cur ? `${cur} ${w}` : w;
    if (measure(font, t, size) > maxW && cur) { lines.push(cur); cur = w; } else cur = t;
  }
  if (cur) lines.push(cur);
  return lines;
}
const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

// ---------- símbolo ----------
// Retícula 120×120. P = contenedor de patrimonio; trazo = trayectoria (no siempre al alza).
const P_PATH = "M30 89V31h27c20 0 31 10 31 26S77 82 57 82H43";
const TREND = "m62 68 12-11 10 7 12-18";
const markColors = {
  light: { tile: C.navy, p: C.paper, trend: C.mint },
  dark: { tile: C.mint, p: C.navy, trend: C.tealDark },
};
function markGroup(variant, idp = "m") {
  if (variant.startsWith("mono")) {
    const ink = variant === "mono-white" ? C.white : C.navy;
    return `<defs><mask id="${idp}-k" maskUnits="userSpaceOnUse" x="0" y="0" width="120" height="120"><rect width="120" height="120" rx="27" fill="#fff"/><path d="${P_PATH}" fill="none" stroke="#000" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/><path d="${TREND}" fill="none" stroke="#fff" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"/><circle cx="96" cy="46" r="9" fill="#fff"/><path d="${TREND}" fill="none" stroke="#000" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="96" cy="46" r="4" fill="#000"/></mask></defs><rect width="120" height="120" rx="27" fill="${ink}" mask="url(#${idp}-k)"/>`;
  }
  const c = markColors[variant];
  return `<rect width="120" height="120" rx="27" fill="${c.tile}"/><path d="${P_PATH}" fill="none" stroke="${c.p}" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/><path d="${TREND}" fill="none" stroke="${c.trend}" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="96" cy="46" r="4" fill="${c.trend}"/>`;
}

// ---------- logotipo horizontal (texto convertido a trazos) ----------
const WORD = outline(bold, "Patrimonio", 148, 68, 45, -1.5);
const CFO = outline(bold, "CFO", 149, 100, 28, 3);
const LOCKUP_W = Math.ceil(148 + Math.max(WORD.width, CFO.width + 1));
function lockupGroup(variant, idp = "l") {
  const word = { light: C.navy, dark: C.white, mono: C.navy, "mono-white": C.white }[variant];
  const cfo = { light: C.teal, dark: C.mint, mono: C.navy, "mono-white": C.white }[variant];
  const mv = variant === "mono" ? "mono" : variant === "mono-white" ? "mono-white" : variant;
  return `${markGroup(mv, idp)}<path d="${WORD.d}" fill="${word}"/><path d="${CFO.d}" fill="${cfo}"/>`;
}
const svg = (w, h, body, label = "Patrimonio CFO") =>
  `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" role="img" aria-label="${label}"><title>${label}</title>${body}</svg>\n`;

function png(svgText, outPath, width) {
  const r = new Resvg(svgText, {
    fitTo: width ? { mode: "width", value: width } : { mode: "original" },
    font: { fontFiles: [REG, BOLD], loadSystemFonts: false, defaultFontFamily: "Arial" },
  });
  writeFileSync(outPath, r.render().asPng());
}

const brandDir = join(root, "public/brand");
mkdirSync(brandDir, { recursive: true });
const out = [];
const write = (p, s) => { writeFileSync(p, s); out.push(p.replace(root + "\\", "").replace(root + "/", "")); };

// Símbolos
for (const v of ["light", "dark", "mono", "mono-white"]) {
  const name = { light: "logo-mark", dark: "logo-mark-dark", mono: "logo-mark-mono", "mono-white": "logo-mark-mono-white" }[v];
  write(join(brandDir, `${name}.svg`), svg(120, 120, markGroup(v)));
}
// Logotipos
for (const v of ["light", "dark", "mono", "mono-white"]) {
  const name = { light: "logo-horizontal", dark: "logo-horizontal-dark", mono: "logo-horizontal-mono", "mono-white": "logo-horizontal-mono-white" }[v];
  write(join(brandDir, `${name}.svg`), svg(LOCKUP_W, 120, lockupGroup(v)));
}
// Exportables PNG
const markSvg = svg(120, 120, markGroup("light"));
for (const s of [32, 180, 192, 512]) png(markSvg, join(brandDir, `icon-${s}.png`), s), out.push(`public/brand/icon-${s}.png`);
png(svg(LOCKUP_W, 120, lockupGroup("light")), join(brandDir, "logo-horizontal@2x.png"), LOCKUP_W * 2); out.push("public/brand/logo-horizontal@2x.png");
png(svg(LOCKUP_W, 120, lockupGroup("dark")), join(brandDir, "logo-horizontal-dark@2x.png"), LOCKUP_W * 2); out.push("public/brand/logo-horizontal-dark@2x.png");

// Hoja de construcción: zona de protección = 1/4 del ancho del símbolo (30 u).
{
  const pad = 30, W = Math.max(800, LOCKUP_W + pad * 2 + 80), H = 120 + pad * 2 + 80;
  const body = `<rect width="${W}" height="${H}" fill="${C.bg}"/><g transform="translate(40 40)"><rect width="${LOCKUP_W + pad * 2}" height="${120 + pad * 2}" fill="none" stroke="${C.loss}" stroke-dasharray="6 6"/><g transform="translate(${pad} ${pad})">${lockupGroup("light", "cs")}<rect x="0" y="-${pad}" width="${pad}" height="${pad}" fill="${C.loss}" opacity=".25"/></g></g><text x="40" y="${H - 12}" font-family="Arial" font-size="16" fill="${C.muted}">Zona de protección mínima: x = 1/4 del ancho del símbolo. Mínimo: símbolo 32 px · logotipo 180 px de ancho.</text>`;
  write(join(brandDir, "construccion.svg"), svg(W, H, body, "Construcción del logotipo"));
}

// ---------- piezas sociales ----------
const posts = JSON.parse(readFileSync(join(root, "brand/content/posts.json"), "utf8")).posts;
const fmt = (c) => (c < 0 ? "−" : c > 0 ? "+" : "") + "$" + (Math.abs(c) / 100).toLocaleString("en-US", { minimumFractionDigits: Math.abs(c) % 100 ? 2 : 0 });
const money = (c) => "$" + (c / 100).toLocaleString("en-US", { minimumFractionDigits: 2 });

function verify(p) {
  const ck = p.check;
  if (ck.type === "balances") {
    const base = { month: "2026-07", investments: 0, otherAssets: 0, income: null, living: null, interest: null, principal: null, contributions: null, housing: null, goal: null };
    const x = explainChange({ ...base, ...ck.prev }, { ...base, month: "2026-08", ...ck.curr });
    const expect = [fmt(x.cash), fmt(x.debt), fmt(x.netWorth).replace(/^[+−]?\$0$/, "$0")];
    const got = [p.rows[0].value, p.rows[1].value, p.result.value];
    if (expect.join("|") !== got.join("|")) throw new Error(`${p.id}: cifras ${got} ≠ motor ${expect}`);
  } else if (ck.type === "loan") {
    const s = splitPayment(ck.balance, ck.aprBps, ck.payment);
    if (s.interest !== ck.interest || s.principal !== ck.principal) throw new Error(`${p.id}: interés/capital no cuadran con el motor`);
    const got = [p.rows[0].value, p.rows[1].value, p.result.value];
    const expect = [money(s.interest), money(s.principal), money(ck.payment)];
    if (expect.join("|") !== got.join("|")) throw new Error(`${p.id}: cifras ${got} ≠ motor ${expect}`);
  }
}

const FORMATS = {
  "1x1": { h: 1080, head: 70, row: 92, pad: 72 },
  "4x5": { h: 1350, head: 82, row: 112, pad: 80 },
  "9x16": { h: 1920, head: 96, row: 136, pad: 84 },
};

function post(p, f, slack = 0) {
  const W = 1080, H = f.h, X = f.pad, inner = W - X * 2;
  const k = f.head / 82; // escala relativa
  const t = (x, y, size, fill, text, o = {}) =>
    `<text x="${x}" y="${y}" font-family="Arial, Helvetica, sans-serif" font-size="${size}"${o.bold ? ' font-weight="700"' : ""}${o.anchor ? ` text-anchor="${o.anchor}"` : ""}${o.ls ? ` letter-spacing="${o.ls}"` : ""} fill="${fill}">${esc(text)}</text>`;
  let y = X;
  let b = `<rect width="${W}" height="${H}" fill="${C.navy}"/><path d="M0 ${H * 0.74}Q${W * 0.42} ${H * 0.56} ${W} ${H * 0.68}V${H}H0Z" fill="${C.navy2}"/>`;
  // Marca completa (logotipo oscuro), altura 64 px.
  const LH = Math.round(76 * k); const ls = LH / 120;
  b += `<g transform="translate(${X} ${y}) scale(${ls})">${lockupGroup("dark", `p${p.id}`)}</g>`;
  y += LH + 70 * k + slack;
  b += t(X, y, Math.round(30 * k), C.mint, p.eyebrow, { bold: true, ls: 2 });
  y += 30 * k + 28 * k;
  // El titular se reduce hasta caber en el ancho útil; nunca se recorta.
  const hs = Math.floor(Math.min(f.head, ...p.headline.map((l) => (f.head * inner) / measure(bold, l, f.head))));
  for (const line of p.headline) { y += hs; b += t(X, y, hs, C.white, line, { bold: true }); y += hs * 0.14; }
  y += 44 * k;
  // Tarjeta de datos
  const cardH = f.row * 2 + f.row * 1.25 + 40 * k;
  const cy = y;
  b += `<rect x="${X}" y="${cy}" width="${inner}" height="${cardH}" rx="${28 * k}" fill="${C.paper}"/>`;
  let ry = cy + 20 * k;
  const lab = Math.round(36 * k), note = Math.round(26 * k);
  for (const r of p.rows) {
    const base = ry + f.row / 2 + lab * 0.35;
    b += t(X + 44 * k, base - note * 0.45, lab, C.navy, r.label, { bold: true });
    b += t(X + 44 * k, base + note * 0.95, note, C.muted, r.note);
    b += t(W - X - 44 * k, base + lab * 0.1, Math.round(44 * k), C.navy, r.value, { bold: true, anchor: "end" });
    ry += f.row;
    b += `<path d="M${X + 44 * k} ${ry}H${W - X - 44 * k}" stroke="${C.line}" stroke-width="2"/>`;
  }
  const rv = p.result.value;
  const rc = rv.startsWith("+") ? C.teal : rv.startsWith("−") ? C.loss : C.navy;
  const rb = ry + f.row * 0.62 + 20 * k;
  b += t(X + 44 * k, rb, Math.round(40 * k), C.navy, p.result.label, { bold: true });
  b += t(W - X - 44 * k, rb + 6 * k, Math.round(64 * k), rc, rv, { bold: true, anchor: "end" });
  y = cy + cardH + 56 * k;
  // Pie explicativo
  const fs = Math.round(34 * k);
  for (const line of wrap(reg, p.footer, fs, inner)) { y += fs; b += t(X, y, fs, "#DCE7EE", line); y += fs * 0.3; }
  // CTA y aviso
  const noteY = H - X + 10;
  const ctaH = Math.round(84 * k), ctaFs = Math.round(32 * k);
  const ctaW = measure(bold, p.cta, ctaFs) + 64 * k;
  const ctaY = noteY - 40 * k - ctaH;
  if (f.measure) return ctaY - y;
  if (ctaY > y + 30 * k) {
    b += `<rect x="${X}" y="${ctaY}" width="${ctaW}" height="${ctaH}" rx="${ctaH / 2}" fill="${C.mint}"/>`;
    b += t(X + 32 * k, ctaY + ctaH / 2 + ctaFs * 0.36, ctaFs, C.navy, p.cta, { bold: true });
  } else throw new Error(`${p.id} ${H}: el contenido no cabe; acorta el texto`);
  b += t(X, noteY, Math.round(24 * k), C.mist, "Ejemplo ilustrativo · cifras redondeadas al centavo");
  return svg(W, H, b, `Patrimonio CFO · ${p.headline.join(" ")}`);
}

const captions = ["# Captions · piezas sociales\n", "Generado desde `brand/content/posts.json`. Todas las cifras son ilustrativas y se verifican con `lib/finance/engine.ts`. No anuncian acceso público ni conexión bancaria.\n"];
for (const p of posts) {
  verify(p);
  const dir = join(root, "brand/social", p.id);
  mkdirSync(dir, { recursive: true });
  for (const [name, f] of Object.entries(FORMATS)) {
    const free = post(p, { ...f, measure: true }) - 60;
    const s = post(p, f, Math.max(0, free * 0.45));
    write(join(dir, `${name}.svg`), s);
    png(s, join(dir, `${name}.png`)); out.push(`brand/social/${p.id}/${name}.png`);
  }
  captions.push(`## ${p.id}\n\n**Titular:** ${p.headline.join(" ")}\n\n${p.caption}\n\n**Alt text:** ${p.headline.join(" ")} ${p.rows.map((r) => `${r.label} ${r.value} (${r.note})`).join(", ")}; ${p.result.label} ${p.result.value}. Ejemplo ilustrativo.\n`);
}
write(join(root, "brand/social/CAPTIONS.md"), captions.join("\n"));
console.log(`OK · ${out.length} archivos\n` + out.join("\n"));
