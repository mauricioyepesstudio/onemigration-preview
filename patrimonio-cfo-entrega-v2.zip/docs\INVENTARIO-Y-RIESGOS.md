# Patrimonio CFO: inventario y riesgos

28 de septiembre de 2026 · auditoría previa a los cambios

## 1. Qué había disponible

| Pieza | Estado | Fuente |
| --- | --- | --- |
| `docs/IDENTIDAD-Y-UX.md`, `docs/ENCARGO-AGENCIA-CLAUDE.md` | Leído | `patrimonio-cfo-brand-kit.zip` |
| `public/brand/*` (4 logos SVG, 3 posts SVG+PNG) | Leído; copia v1 en `brand/legacy-v1/` | zip |
| `app/finance-app.tsx` | **No disponible en código fuente.** Reconstruido desde el bundle publicado `finance-app-D0IonieK.js` | sitio en producción |
| `app/api/finance/route.ts`, `app/api/loans/route.ts` | **No disponible.** Solo se observa el contrato: `GET → {months:[]}` / `{loans:[]}`, `PUT` con upsert por mes / por id, `DELETE {id}` | red del sitio |
| `db/schema.ts`, `wrangler` y migraciones D1 | **No disponible** | n/a |
| Autenticación y aislamiento por usuario | **No verificable** sin el servidor | n/a |
| Datos actuales de la cuenta | `months: []`, `loans: []`: no hay cifras guardadas todavía | `GET /api/finance`, `/api/loans` |

El repositorio no está en este equipo (busqué en `C:\Users\graphics1`, `N:` y `P:`), y el sitio se publica en `*.chatgpt.site`, una plataforma a la que este entorno no tiene acceso de despliegue. **Sin el repositorio no puedo modificar la app publicada, ejecutar su build ni desplegar.** Todo lo que se entrega aquí está diseñado para integrarse sin cambios de contrato (ver §4).

## 2. Modelo de datos actual (inferido del cliente)

```ts
MonthClose { month: "YYYY-MM"; cash; investments; otherAssets; debt;           // centavos, ≥ 0
             income|living|interest|principal|contributions|housing|goal: number|null }
Loan       { id; name; balance; aprBps; payment }                               // centavos / puntos básicos
```

Patrimonio = `cash + investments + otherAssets − debt`. Los importes se guardan como centavos enteros, así que no hay error de coma flotante en el balance.

## 3. Riesgos encontrados

Orden: precisión, luego privacidad, luego UX.

| # | Riesgo | Severidad | Evidencia | Resolución |
| --- | --- | --- | --- | --- |
| R1 | **Crecimiento % engañoso con patrimonio anterior negativo.** Usa `Math.abs(prev)`: pasar de −$3,300 a +$1,400 aparece como "+142 %". | Alta | `ratios`, bundle | `ratios()` devuelve `null` con motivo si la base es ≤ 0. Prueba incluida. |
| R2 | **Meses faltantes invisibles.** "Cambio frente a" compara con el cierre anterior disponible aunque falten meses; el % de crecimiento mezcla varios meses como si fuera uno. | Alta | `E = e[w+1]` | `missingMonths()`, aviso `gap` y crecimiento % suspendido. |
| R3 | **La deuda de préstamos y la deuda del cierre no se concilian.** El préstamo no actualiza el cierre (a propósito, para no sumar dos veces), pero nada avisa si difieren. | Media | Texto en la pestaña Préstamos | Aviso `principal_exceeds/below_debt_drop`; en el modelo extendido, las cuentas pasivas se enlazan con `loan_id`. |
| R4 | **Sobrescritura silenciosa**: guardar un cierre con un mes que ya existe lo reemplaza sin confirmar. | Media | `PUT /api/finance` hace upsert | Confirmar en la UI cuando el mes ya existe (pendiente de integración). |
| R5 | **La deuda que aumenta se muestra como "Reducción de deuda" negativa**, sin explicar si hubo nueva disposición. | Media | fila "Reducción de deuda" | Aviso `debt_increased`; con libro, `borrowing` es patrimonio-neutro. |
| R6 | **Herramienta para agentes del navegador**: `document.modelContext.registerTool('read_financial_summary')` expone el patrimonio a cualquier agente con acceso a la pestaña. | Media (privacidad) | bundle | Decisión de producto: dejarla opt-in o retirarla. **No la amplié.** |
| R7 | **Mensajes de error con estilo de éxito**: el banner `role=status` teal muestra también "No se pudo eliminar". | Baja | bundle | Separar `status` y `alert` (pendiente de integración). |
| R8 | El botón de cierre del diálogo dice **"Close"** (en inglés) en una app en español. | Baja | shadcn `Dialog` | Traducir a "Cerrar". |
| R9 | `confirm()` nativo para borrar préstamos: no es accesible ni consistente con la marca. | Baja | bundle | Diálogo propio. |
| R10 | **Marca no vectorial**: los logotipos usaban `<text>` en Arial, así que se renderizan distinto sin esa fuente. Los posts usaban una "P" tipográfica en lugar del símbolo. La versión "mono" era bicolor. | Media (marca) | `public/brand/*.svg` | Logotipos convertidos a trazos, mono real con calado y posts con el símbolo (§4). |
| R11 | Contraste del trazo `#127C70` sobre `#72E3B2` en el logo oscuro: 3.22:1. | Baja | cálculo | Cambiado a `#0B5147` (5.85:1). |
| R12 | Aislamiento por usuario, validación en servidor y límites de tamaño **no verificados**: el cliente valida, pero no puedo ver el servidor. | Desconocida | n/a | Revisar en cuanto esté el repo (lista en §5). |

## 4. Qué se entrega aquí (listo para integrar)

| Archivo | Qué es | Verificación |
| --- | --- | --- |
| `lib/finance/engine.ts` | Motor puro: balance, explicación del cambio, flujo, 6 ratios con definición, reparto interés/capital, liquidación, meses faltantes, libro de transacciones y conciliación por cuenta. Usa los mismos tipos `MonthClose`/`Loan`. | 15 pruebas |
| `db/migrations/0002_accounts_ledger.sql` | Migración **aditiva** de D1: `accounts`, `account_balances`, `transactions` con fuente y fecha, restricciones, deduplicación de CSV y sin borrado en cascada del historial | 3 pruebas contra SQLite |
| `public/brand/*` v2 | Símbolo y logotipo vectoriales en 4 variantes, PNG exportables, iconos 32/180/192/512 y hoja de construcción | Render revisado |
| `brand/content/posts.json` + `scripts/build-brand.mjs` | Sistema social editable: 3 publicaciones × 3 formatos (1:1, 4:5, 9:16). Las cifras se verifican con el motor antes de exportar, y el build falla si el texto no cabe. | Build OK, 9 PNG |
| `brand/social/CAPTIONS.md` | Captions y texto alternativo | n/a |
| `docs/IDENTIDAD-Y-UX.md` v2 | Sistema de marca completo y especificación UX por pantalla | n/a |

Comandos: `npm test` (18/18 en verde), `npm run typecheck` (sin errores, modo estricto) y `npm run brand`.

## 5. Qué necesito para completar la integración y publicar

1. **El repositorio completo** (zip del proyecto o acceso git): `app/`, `db/schema.ts`, `wrangler.*`, `package.json`.
2. **El flujo de publicación actual** del sitio en `chatgpt.site` (comando o pasos). Sin él no puedo desplegar ni sé si las migraciones de D1 se aplican de forma automática o manual.

Con eso: reemplazo los cálculos inline de `finance-app.tsx` por `engine.ts`, aplico R4/R7/R8/R9, añado las pantallas nuevas (cuentas, transacciones, incorporación guiada), ajusto `user_id` en la migración al esquema real, reviso R12 en el servidor, ejecuto el build del proyecto y publico por el flujo existente sin ampliar permisos.
